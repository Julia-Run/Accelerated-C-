//
// Created by FORREST1901 on 9/16/20.
//

#include <iostream>

using namespace std;

int main(int argc, char **argv) {

    cout << "Hello, world!" << endl;

    return 0;
}